#!/bin/bash
[[ $# = 2 ]] && echo $(( $1 + $2 )) || { echo "Wrong number of arguments, expected 2"; exit 1;  };


